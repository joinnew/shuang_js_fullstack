// 在这里管理项目中的常量

// 输出一堆， 引入时用解构{} []
// 模块 json 
export const USER_INFO = 'userInfo';

export const USER_SPECIAL_INFO = 'user_special_info';

export const SYSTEM_INFO = "systemInfo";